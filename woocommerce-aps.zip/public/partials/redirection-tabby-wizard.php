<?php
if (!defined('ABSPATH')) {
    exit;
}
$terms_text = __('I agree with Tabby', 'amazon-payment-services');
$terms_text .= ' <span class="aps-modal-open" data-modal="terms-modal">' . __('terms and condition', 'amazon-payment-services') . '</span> ';
$terms_text .= __('to proceed with the transaction', 'amazon-payment-services');


?>