<?php echo '<button type="button" id="applePay" class="' . wp_kses_data( $apple_pay_class ) . '"> </button>';
